<?php
$koneksi=mysql_connect("localhost","root","");
mysql_select_db("spas12bdg",$koneksi);
?>